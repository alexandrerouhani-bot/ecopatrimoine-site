# ÉcoPatrimoine — Site HTML

## Déploiement sur Netlify

1. Allez sur https://app.netlify.com
2. Créez un compte (avec Google ou email)
3. Cliquez sur "Add new site" → "Deploy manually"
4. Glissez le dossier ZIP que vous avez téléchargé ici.
5. Votre site sera en ligne immédiatement sous une URL comme : https://ecopatrimoine.netlify.app

## Contenu du site
- index.html : la page principale du site ÉcoPatrimoine.
